# Responsive Navigation Bar
## [Watch it on youtube](https://youtu.be/k-jwXwpNuXI)
### Responsive Navigation Bar

- Responsive Navigation Bar Using HTML CSS & JavaScript
- With Dropdown Mega Menu
- With a beautiful minimalist interface.
- Developed first with the Mobile First methodology, then for desktop.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/@Bedimcode)

![preview img](/preview.png)
